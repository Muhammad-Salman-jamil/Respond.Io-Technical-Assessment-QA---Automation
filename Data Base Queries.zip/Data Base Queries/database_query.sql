-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2022 at 07:23 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database query`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(1) NOT NULL,
  `firstName` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `firstName`, `lastName`, `email`, `phone`) VALUES
(1, 'Aaron', 'Foster', 'aaron.foster@gm', NULL),
(2, 'Bob', 'Garret', NULL, '60123456790'),
(3, 'Charles', 'Hoskinson', 'charles.hoskinson@do', '60123456791'),
(4, 'Darren', 'Irving', 'darren_irving90@test.com', NULL),
(5, 'Emily', 'Jokovich', 'emily.j@test.com', '60123456793');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `customerName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `customerName`, `phone`) VALUES
(1, 'Anakin Funster', '55512345678'),
(2, 'Barry White', '55512345679'),
(3, 'Charles Kindred', '55512345680'),
(4, 'Julio Sanchez', '55512345681'),
(5, 'Morty O’Neill', '55512345682');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderId` int(2) NOT NULL,
  `customerId` int(10) NOT NULL,
  `orderDate` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderId`, `customerId`, `orderDate`) VALUES
(1001, 3, '1998-04-10'),
(1002, 2, '2002-10-23'),
(1003, 4, '1981-05-24'),
(1004, 4, '1996-09-20'),
(1005, 1, '1990-11-26'),
(1006, 2, '2022-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(2) NOT NULL,
  `groupId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `LastName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `groupId`, `firstName`, `LastName`, `email`) VALUES
(1, 'group_02', 'Amelia', 'Kelly', 'amelia_kelly@test.com'),
(2, 'group_01', 'Beth', 'La’ Salle', 'beth_123@company.io'),
(3, 'group_02', 'Cecilia', 'Montgomery', 'cecilia90@gmail.com'),
(4, 'group_03', 'Dorothy', 'Nikolai', 'dorothy.n@domain com'),
(5, 'group_03', 'Emily', 'O’ Shea', 'emily_flowers@yahoo.com'),
(6, 'group_01', 'Fiona', 'Peterson', 'fiona.p.123@domain.com'),
(7, 'group_02', 'Gertrude', 'Quinn', 'g.quinn@outlook.com'),
(8, 'group_04', 'Heather', 'Rose', 'h.amber@company.net'),
(9, 'group_01', 'Iona', 'Smith', 'iona@test.com'),
(10, 'group_04', 'Jasmine', 'Tatcher ', 'jasmine.t@domain.io');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
