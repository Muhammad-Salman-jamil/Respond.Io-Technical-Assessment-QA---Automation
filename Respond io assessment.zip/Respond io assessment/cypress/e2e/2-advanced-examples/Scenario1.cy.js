/// <reference types="cypress" />
describe('Scenario 1 Assessment', ()=>{

it('visit the site', function(){

    cy.visit('http://automationpractice.com/index.php')
    cy.wait(5000)
    cy.get('#search_query_top').click().type('Faded Short Sleeve T-shirts')
    cy.get(".button-search").click()
    cy.wait(5000)
    cy.get('.product-name').contains('Faded Short Sleeve T-shirts')
     
})

})