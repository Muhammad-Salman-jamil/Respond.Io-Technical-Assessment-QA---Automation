/// <reference types="cypress" />
describe('Scenario 1 Assessment', ()=>{

    it('visit the site', function(){
    
        cy.visit('http://automationpractice.com/index.php')
        cy.wait(3000)
        cy.get(".sf-with-ul").first().click()
        cy.wait(10000)
        cy.get('#layered_category_8').click()
        cy.wait(10000)
        cy.get('#layered_id_attribute_group_13').click()
        cy.wait(10000)
        cy.get('.product-name').contains('Dress')
    
    
        
         
    })
    
    })