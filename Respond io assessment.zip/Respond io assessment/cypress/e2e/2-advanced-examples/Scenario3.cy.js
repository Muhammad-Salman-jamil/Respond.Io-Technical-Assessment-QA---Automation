/// <reference types="cypress" />
describe('Scenario 1 Assessment', ()=>{

    it('visit the site', function(){
    
        cy.visit('http://automationpractice.com/index.php')
        cy.wait(5000)
        cy.get('.product_img_link').first().click({ force: true })
        cy.wait(2000)
        cy.get('#add_to_cart > .exclusive').click()
        cy.wait(15000)
        cy.contains('Product successfully added to your shopping cart').should('be.visible')
        
         
    })
    
    })